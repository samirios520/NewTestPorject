//
//  ContentView.swift
//  Newtest
//
//  Created by samir on 11/04/25.
//

import SwiftUI
import CoreData

struct ContentView: View {
    
    @State private var searchText = ""
    @StateObject private var productViewModel = ProductViewModel()
    @StateObject private var cartViewModel = CartViewModel()
       
       let columns = [
           GridItem(.flexible()),
           GridItem(.flexible())
       ]
    var body: some View {
        NavigationView {
                    ScrollView {
                        VStack(spacing: 0) {
                            CustomHeaderView()
                            CustomSearchField(searchText: $searchText)
                                .padding(.vertical)
                            PromotionalBannerView()
                            
                            CategoriesView()
                                .padding(.top)
                            
                            // Product Grid
                            LazyVGrid(columns: columns, spacing: 16) {
                                ForEach(productViewModel.products) { product in
                                    ProductGridItem(product: product)
                                }
                            }
                            .padding()
                        }
                    }
                }
                 .environmentObject(cartViewModel)
                .onAppear {
                    productViewModel.fetchProducts()
                }
        
    }

}
