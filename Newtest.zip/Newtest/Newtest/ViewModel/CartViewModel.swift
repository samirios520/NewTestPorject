//
//  CartViewModel.swift
//  Newtest
//
//  Created by samir on 11/04/25.
//

import SwiftUI

class CartViewModel: ObservableObject {
    @Published var cartItems: [CartItem] = []
    @Published var cartTotal: Double = 0
    @Published var selectedItems: Set<Int> = []
    
    struct CartItem: Identifiable {
        let id: Int
        let product: Product
        var quantity: Int
        var isSelected: Bool
    }
    
    var isAllSelected: Bool {
        !cartItems.isEmpty && selectedItems.count == cartItems.count
    }
    
    func addToCart(product: Product) {
        if let index = cartItems.firstIndex(where: { $0.product.id == product.id }) {
            cartItems[index].quantity += 1
        } else {
            let cartItem = CartItem(id: product.id, product: product, quantity: 1, isSelected: false)
            cartItems.append(cartItem)
        }
        updateTotal()
    }
    
    func removeFromCart(productId: Int) {
        cartItems.removeAll { $0.id == productId }
        selectedItems.remove(productId)
        updateTotal()
    }
    
    func updateQuantity(productId: Int, increment: Bool) {
        if let index = cartItems.firstIndex(where: { $0.id == productId }) {
            if increment {
                cartItems[index].quantity += 1
            } else if cartItems[index].quantity > 1 {
                cartItems[index].quantity -= 1
            }
            updateTotal()
        }
    }
    
    func toggleItemSelection(productId: Int) {
        if selectedItems.contains(productId) {
            selectedItems.remove(productId)
        } else {
            selectedItems.insert(productId)
        }
        updateTotal()
    }
    
    func toggleSelectAll() {
        if isAllSelected {
            selectedItems.removeAll()
        } else {
            selectedItems = Set(cartItems.map { $0.id })
        }
        updateTotal()
    }
    
    private func updateTotal() {
        cartTotal = cartItems
            .filter { selectedItems.contains($0.id) }
            .reduce(0) { $0 + ($1.product.price * Double($1.quantity)) }
    }
}
