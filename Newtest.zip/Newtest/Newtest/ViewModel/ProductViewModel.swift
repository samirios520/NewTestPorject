//
//  ProductViewModel.swift
//  Newtest
//
//  Created by Samir on 11/04/25.
//

import Foundation

class ProductViewModel: ObservableObject {
    @Published var products: [Product] = []
    @Published var isLoading = false
    @Published var error: Error?
    
    //fetch the proudct
    
    func fetchProducts() {
        isLoading = true
        guard let url = URL(string: "https://fakestoreapi.com/products") else { return }
        
        URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
            DispatchQueue.main.async {
                self?.isLoading = false
                if let error = error {
                    self?.error = error
                    return
                }
                
                guard let data = data else { return }
                
                do {
                    let products = try JSONDecoder().decode([Product].self, from: data)
                    self?.products = products
                } catch {
                    self?.error = error
                }
            }
        }.resume()
    }
}
