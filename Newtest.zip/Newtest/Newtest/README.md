#  <#Title#>

# My Test App

This is an iOS app built with Swift and SwiftUI.

## 📲 Features

- Design the UI with SwiftUI
- Display data from a REST API
- After tap Corresponding Product show the details view and add cart functionality
- In this App use MVVM ARCHITECTURE.

## 🔧 Installation

1. Clone the repo:
```bash
git clone https://github.com/your-username/your-ios-app.git
