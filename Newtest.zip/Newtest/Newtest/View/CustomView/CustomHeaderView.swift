//
//  CustomHeaderView.swift
//  Newtest
//
//  Created by Samir on 11/04/25.
//

import SwiftUI


// ADD: Custom Header View
struct CustomHeaderView: View {
    var body: some View {
        HStack {
            Button(action: {
                // Add settings action here
            }) {
                Image(systemName: "gearshape.fill")
                    .font(.title2)
                    .foregroundColor(.black)
            }
            
            Spacer()
            
            // Delivery Address
            VStack(alignment: .center, spacing: 2) {
                Text("Delivery to")
                    .font(.caption)
                    .foregroundColor(.gray)
                HStack {
                    Image(systemName: "location.fill")
                        .font(.caption)
                    Text("92 High Street London")
                        .font(.subheadline)
                        .fontWeight(.medium)
                    Image(systemName: "chevron.down")
                        .font(.caption)
                }
            }
            
            Spacer()
            
            Button(action: {
                // Add notification action here
            }) {
                Image(systemName: "bell.fill")
                    .font(.title2)
                    .foregroundColor(.black)
            }
        }
        .padding(.horizontal)
        .padding(.vertical, 8)
    }
}
