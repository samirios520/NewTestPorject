//
//  CategoryItem.swift
//  Newtest
//
//  Created by Samir on 11/04/25.
//

import Foundation
import SwiftUI


struct CategoryItem: View {
    let icon: String
    let name: String
    
    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .font(.title2)
                .frame(width: 50, height: 50)
                .background(Color.gray.opacity(0.1))
                .clipShape(Circle())
            
            Text(name)
                .font(.caption)
                .foregroundColor(.black)
        }
        .frame(width: 70)
    }
}

struct CategoriesView: View {
    let categories = [
        (icon: "iphone", name: "Phone"),
        (icon: "camera", name: "Camera"),
        (icon: "laptopcomputer", name: "Laptop"),
        (icon: "headphones", name: "Audio"),
        (icon: "gamecontroller", name: "Consoles")
    ]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("Categories")
                    .font(.title3)
                    .fontWeight(.bold)
                
                Spacer()
                
                Button(action: {
                    // Action for see all
                }) {
                    Text("See all")
                        .font(.subheadline)
                        .foregroundColor(.blue)
                }
            }
            .padding(.horizontal)
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 20) {
                    ForEach(categories, id: \.name) { category in
                        CategoryItem(icon: category.icon, name: category.name)
                    }
                }
                .padding(.horizontal)
            }
        }
    }
}
