//
//  CartView.swift
//  Newtest
//
//  Created by samir on 11/04/25.
//

import SwiftUI

struct CartView: View {
    @EnvironmentObject var cartVM: CartViewModel
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            VStack {
                if cartVM.cartItems.isEmpty {
                    VStack {
                        Image(systemName: "cart")
                            .font(.system(size: 60))
                            .foregroundColor(.gray)
                        Text("Your cart is empty")
                            .font(.title2)
                            .foregroundColor(.gray)
                            .padding()
                    }
                    .frame(maxHeight: .infinity)
                } else {
                    List {
                        Section {
                            HStack {
                                Button(action: {
                                    cartVM.toggleSelectAll()
                                }) {
                                    Image(systemName: cartVM.isAllSelected ? "checkmark.circle.fill" : "circle")
                                        .foregroundColor(cartVM.isAllSelected ? .blue : .gray)
                                }
                                Text("Select All")
                                    .font(.subheadline)
                            }
                        }
                        
                        ForEach(cartVM.cartItems) { item in
                            HStack(spacing: 12) {
                                // Selection Checkbox
                                Button(action: {
                                    cartVM.toggleItemSelection(productId: item.id)
                                }) {
                                    Image(systemName: cartVM.selectedItems.contains(item.id) ? "checkmark.circle.fill" : "circle")
                                        .foregroundColor(cartVM.selectedItems.contains(item.id) ? .blue : .gray)
                                }
                                
                                // Product Image
                                AsyncImage(url: URL(string: item.product.image)) { image in
                                    image
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                } placeholder: {
                                    ProgressView()
                                }
                                .frame(width: 60, height: 60)
                                
                                // Product Details
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(item.product.title)
                                        .lineLimit(2)
                                        .font(.subheadline)
                                    
                                   
                                    
                                    // Quantity Controls
                                    HStack {
                                        
                                        Text("€\(String(format: "%.2f", item.product.price))")
                                            .font(.headline)
                                            .foregroundColor(.blue)
                                        
                                        Spacer()
                                        
                                        
                                        
                                        Button(action: {
                                            cartVM.updateQuantity(productId: item.id, increment: false)
                                        }) {
                                            Image(systemName: "minus.circle")
                                                .foregroundColor(.gray)
                                        }
                                        
                                        Text("\(item.quantity)")
                                            .frame(minWidth: 30)
                                            .font(.subheadline)
                                        
                                        Button(action: {
                                            cartVM.updateQuantity(productId: item.id, increment: true)
                                        }) {
                                            Image(systemName: "plus.circle")
                                                .foregroundColor(.blue)
                                        }
                                    }
                                }
                            }
                            .padding(.vertical, 4)
                            .swipeActions {
                                Button(role: .destructive) {
                                    cartVM.removeFromCart(productId: item.id)
                                } label: {
                                    Label("Delete", systemImage: "trash")
                                }
                            }
                        }
                    }
                    
                    // Checkout Section
                    VStack(spacing: 16) {
                        HStack {
                            Text("Total:")
                                .font(.title3)
                            Spacer()
                            Text("€\(String(format: "%.2f", cartVM.cartTotal))")
                                .font(.title2)
                                .fontWeight(.bold)
                        }
                        
                        Button(action: {
                            // Implement checkout logic
                        }) {
                            Text("Checkout")
                                .font(.headline)
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.green)
                                .cornerRadius(10)
                        }
                        .disabled(cartVM.selectedItems.isEmpty)
                    }
                    .padding()
                    .background(Color.white)
                    .shadow(radius: 2)
                }
            }
            .navigationTitle("Cart")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        dismiss()
                    }) {
                        Image(systemName: "arrow.left")
                            .foregroundColor(.black)
                    }
                }
            }
        }
    }
}
