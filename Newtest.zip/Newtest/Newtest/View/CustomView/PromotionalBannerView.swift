//
//  PromotionalBannerView.swift
//  Newtest
//
//  Created by Samir on 11/04/25.
//

import SwiftUI


struct PromotionalBannerView: View {
    var body: some View {
        HStack {
            Text("Delivery is 50% cheaper")
                .font(.subheadline)
                .fontWeight(.medium)
                .foregroundColor(.black)
            
            Spacer()
        }
        .padding(.horizontal)
        .padding(.vertical, 12)
        .background(
            LinearGradient(
                gradient: Gradient(colors: [
                    Color.blue.opacity(0.2),
                    Color.green.opacity(0.2)
                ]),
                startPoint: .leading,
                endPoint: .trailing
            )
            .cornerRadius(10.0)
        )
        .padding(.horizontal)
    }
}
