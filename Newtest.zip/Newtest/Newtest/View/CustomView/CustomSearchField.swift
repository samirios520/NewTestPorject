//
//  CustomSearchField.swift
//  Newtest
//
//  Created by Samir on 11/04/25.
//

import SwiftUI


import SwiftUI
import CoreData

struct CustomSearchField: View {
    @Binding var searchText: String
    
    var body: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.gray)
            TextField("Search the Entire Shop", text: $searchText)
                .textFieldStyle(PlainTextFieldStyle())
        }
        .padding(10)
        .background(Color(.systemGray6))
        .cornerRadius(10)
        .padding(.horizontal)
    }
}
