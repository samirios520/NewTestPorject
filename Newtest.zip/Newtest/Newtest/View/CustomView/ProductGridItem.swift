//
//  ProductGridItem.swift
//  Newtest
//
//  Created by Samir on 11/04/25.
//

import Foundation
import SwiftUI

struct ProductGridItem: View {
    let product: Product
    
    var body: some View {
        NavigationLink(destination: ProductDetailsView(product: product)) {
            VStack(alignment: .leading, spacing: 8) {
                AsyncImage(url: URL(string: product.image)) { image in
                    image
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                } placeholder: {
                    ProgressView()
                }
                .frame(height: 150)
                
                Text(product.title)
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .lineLimit(2)
                    .foregroundColor(.black)
                
                Text(product.description)
                    .font(.caption)
                    .foregroundColor(.gray)
                    .lineLimit(2)
                
                HStack {
                    Image(systemName: "star.fill")
                        .foregroundColor(.yellow)
                    Text(String(format: "%.1f", product.rating.rate))
                    Text("(\(product.rating.count))")
                        .foregroundColor(.gray)
                }
                .font(.caption)
                
                Text("€\(String(format: "%.2f", product.price))")
                    .font(.headline)
                    .fontWeight(.bold)
            }
            .padding()
            .background(Color.white)
            .cornerRadius(10)
            .shadow(radius: 2)
        }
    }
}
