//
//  ProductDetailView.swift
//  Newtest
//
//  Created by Samir on 11/04/25.
//

import SwiftUI

struct ProductDetailsView: View {
    let product: Product
    @Environment(\.dismiss) private var dismiss
    @State private var isLiked = false
    @State private var showingCart = false
    @EnvironmentObject var cartVM: CartViewModel
    
    var body: some View {
        ScrollView {
            VStack(alignment: .center, spacing: 16) {
                // Custom Header
                HStack {
                    Button(action: {
                        dismiss()
                    }) {
                        Image(systemName: "arrow.left")
                            .font(.title2)
                            .foregroundColor(.black)
                    }
                    
                    Spacer()
                    
                    Button(action: {
                        isLiked.toggle()
                    }) {
                        Image(systemName: isLiked ? "heart.fill" : "heart")
                            .font(.title2)
                            .foregroundColor(isLiked ? .red : .black)
                    }
                    
                    Button(action: {
                        shareProduct()
                    }) {
                        Image(systemName: "square.and.arrow.up")
                            .font(.title2)
                            .foregroundColor(.black)
                    }
                    .padding(.leading, 16)
                }
                .padding()
                
                // Product Image
                AsyncImage(url: URL(string: product.image)) { image in
                    image
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                } placeholder: {
                    ProgressView()
                }
                .frame(height: 300)
                
                // Product Details
                VStack(alignment: .leading, spacing: 16) {
                    Text(product.title)
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    HStack {
                        HStack {
                            Image(systemName: "star.fill")
                                .foregroundColor(.yellow)
                            Text(String(format: "%.1f", product.rating.rate))
                            Text("(\(product.rating.count) reviews)")
                                .foregroundColor(.gray)
                        }
                        .font(.subheadline)
                        
                        Spacer()
                        
                        Text("$\(String(format: "%.2f", product.price))")
                            .font(.title2)
                            .fontWeight(.bold)
                    }
                    
                    Text("Description")
                        .font(.headline)
                        .padding(.top)
                    
                    Text(product.description)
                        .font(.body)
                        .foregroundColor(.gray)
                        .lineSpacing(4)
                    
                    // Add to Cart Button
                    Button(action: {
                        cartVM.addToCart(product: product)
                        showingCart = true
                    }) {
                        Text("Add to Cart")
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.green)
                            .cornerRadius(10)
                    }
                    .padding(.top, 20)
                }
                .padding()
            }
        }
        .navigationBarHidden(true)
        .sheet(isPresented: $showingCart) {
            CartView()
        }
    }
    
    private func shareProduct() {
        guard let url = URL(string: product.image) else { return }
        let activityVC = UIActivityViewController(
            activityItems: [url],
            applicationActivities: nil
        )
        
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let window = windowScene.windows.first,
           let rootVC = window.rootViewController {
            rootVC.present(activityVC, animated: true)
        }
    }
}
